package com.example.sqllitedemo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
